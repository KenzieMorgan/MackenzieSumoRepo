using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    // Determines the speed of how fast the player will move
    public float mSpeed;

    private Rigidbody prBody;

    private GameObject focalPoint;

    public bool powerUp = false;

    public float pushPower;

    public float waitTime;

    public GameObject puIndicator;

    public AudioSource hitSound;

    public bool isGrounded;

    public float jumpForce;

    // Start is called before the first frame update
    void Start()
    {

        // Makes the rigid body the one attached to the player
        prBody = GetComponent<Rigidbody>();

        // Creates reference to CameraFocus from Unity
        focalPoint = GameObject.Find("CameraFocus");
    
    }

    // Update is called once per frame
    [System.Obsolete]
    void Update()
    {

        // Creates inputs for movement
        float fInput = Input.GetAxis("Vertical");

        // When movement keys are pressed adds force to the player
        prBody.AddForce(focalPoint.transform.forward * fInput * mSpeed);

        // Resets the level if you fall off the platform
        if (transform.position.y < -40)
        {

            Application.LoadLevel(Application.loadedLevel);

        }
        Controller();
        puIndicator.transform.position = transform.position;

    }

    private void OnTriggerEnter(Collider other)
    {
        
        if (other.CompareTag("PowerUp"))
        {

            powerUp = true;
            puIndicator.gameObject.SetActive(true);
            Destroy(other.gameObject);
            StartCoroutine(powerupCountdownRoutine());
         
        }

    }

    IEnumerator powerupCountdownRoutine()
    {

        yield return new WaitForSeconds(waitTime);
        powerUp = false;
        puIndicator.gameObject.SetActive(false);
        Debug.Log("Wait Done");

    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {

            isGrounded = true;

        }
        if (collision.gameObject.CompareTag("Enemy"))
        {

         hitSound.Play();

        }

        if (collision.gameObject.CompareTag("Enemy") && powerUp)
        {           

            Rigidbody erBody = collision.gameObject.GetComponent<Rigidbody>();

            Vector3 awayFromPlayer = collision.gameObject.transform.position - transform.position;

            erBody.AddForce(awayFromPlayer * pushPower, ForceMode.Impulse);

            Debug.Log("Collided with: " + collision.gameObject.name);




        }

    }
    private void OnCollisionStay(Collision collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        isGrounded = true;

    }
    public void Controller()
    {
        if (Input.GetKeyDown(KeyCode.Space) && isGrounded == true)
        {

            Debug.Log("jump");
            prBody.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
            isGrounded = false;

        }
                    
    }
    private void OnCollisionExit(Collision collision)
    {

        isGrounded = false;

    }

}
