using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateCamera : MonoBehaviour
{
    
    // Sets the rotation speed of the camera
    public float rotationSpeed;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        // Gets input from unity in order to control the camera
        float horizontalInput = Input.GetAxis("Horizontal");

        // Makes it so that the camera can rotate
        transform.Rotate(Vector3.up, horizontalInput * rotationSpeed *Time.deltaTime);

    }
}
