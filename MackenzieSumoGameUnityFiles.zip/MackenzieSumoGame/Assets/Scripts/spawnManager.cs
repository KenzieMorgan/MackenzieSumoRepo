using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spawnManager : MonoBehaviour
{

    public GameObject ePrefab;

    private float spawnRange = 9.0f;

    public int enemyCount;

    private int waveNumber = 0;

    public GameObject powerUpBounce;

    // Start is called before the first frame update
    void Start()
    {



    }

    // Update is called once per frame
    void Update()
    {

        enemyCount = FindObjectsOfType<enemyController>().Length;
        if (enemyCount == 0)
        {

            waveNumber++;

            spawnEnemy(waveNumber);

            Instantiate(powerUpBounce, GenerateSpawnPos(), powerUpBounce.transform.rotation);

        }

    }
    
    void spawnEnemy(int enemiesToSpawn)
    {

        for (int i = 0; i < enemiesToSpawn; i++)
        {

            Instantiate(ePrefab, GenerateSpawnPos(), ePrefab.transform.rotation);

        }

    }

    // Generates random position for enemies to spawn with
    private Vector3 GenerateSpawnPos()
    {

        float spawnPosX = Random.Range(-spawnRange, spawnRange);
        float spawnPosY = Random.Range(-spawnRange, spawnRange);

        Vector3 RandomPos = new Vector3(spawnPosX, 0, spawnPosY);

        return RandomPos;

    }
}
